<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" integrity="" crossorigin="anonymous">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Additional CSS Files -->
<link rel="stylesheet" href="assets/css/fontawesome.css">
<link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
<link rel="stylesheet" href="assets/css/owl.css">
<link rel="stylesheet" href="assets/css/lightbox.css">


    <style>
        body { background:scroll;
        color: violet ;
        font-family: Arial, Helvetica, sans-serif;
        background-color:darkgoldenrod;
        }
    </style>
</head>
<body>
<section class="section coming-soon" data-section="#">
    <label for="login" class="col">Already have an Account?</label>
    <a href="login.php"><input type="Button" class="btn btn-primary" name="login" value="Login"  />
      
    <h3 align="center" style="font: size 23px;color: gold;"> Visiting Us for the first time??</h3>
    <div class="container">
    <fieldset>  
    <h5>Please Sign Up</h5>
<div class="container-fluid">
    <form action="serverlogins.php" method="post" name="Signup" id="signup" class="form-horizontal">
        <label for="Username" class="col-">Username</label>
       <input type="text" class="form-control" id="username" name="username" placeholder="Enter a Unique Username" />
       <label for="Phonenumber" class="col-">Phone Number</label>
       <input type="text" class="form-control" id="Phone Number" name="Phone Number" placeholder="Enter your Phone Number" />
       <label for="email" class="col-">Email</label>
       <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email Address"/> 
       <label for="Password_1" class="col"> Password</label>
       <input type="password" class="form-control" id="Password_1" name="Password_1" placeholder="Enter a Strong Password" />
       <label for="Password_2" class="col">Confirm Password</label>
       <input type="password" class="form-control" id="Password_2" name="Password_2" placeholder="Confirm Password" />
       <input type="Submit" class="btn btn-primary" name="submitSignUp" value="Submit" />

    </form>
</div>
</fieldset>  
</div>
    
    </section>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/isotope.min.js"></script>
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/lightbox.js"></script>
<script src="assets/js/tabs.js"></script>
<script src="assets/js/video.js"></script>
<script src="assets/js/slick-slider.js"></script>
<script src="assets/js/custom.js"></script>

</body>
</html>