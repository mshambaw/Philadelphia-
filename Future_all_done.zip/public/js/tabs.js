(function() {
    const second = 1000,
        minute = second * 60,
        hour = minute * 60,
        day = hour * 24;

    //I'm adding this section so I don't have to keep updating this pen every year :-)
    //remove this if you don't need it
    let today = new Date(),
        dd = String(today.getDate()).padStart(2, "0"),
        mm = String(today.getMonth() + 1).padStart(2, "0"),
        yyyy = today.getFullYear(),
        nextYear = yyyy + 1,
        dayMonth = "12/19/",
        birthday = dayMonth + yyyy;

    today = mm + "/" + dd + "/" + yyyy;
    if (today > birthday) {
        birthday = dayMonth + nextYear;
    }
    //end

    const countDown = new Date(birthday).getTime(),
        x = setInterval(function() {

            const now = new Date().getTime(),
                distance = countDown - now;

            document.getElementsByClassName("days").innerText = Math.floor(distance / (day)),
                document.getElementsByClassName("hours").innerText = Math.floor((distance % (day)) / (hour)),
                document.getElementsByClassName("minutes").innerText = Math.floor((distance % (hour)) / (minute)),
                document.getElementsByClassName("seconds").innerText = Math.floor((distance % (minute)) / second);

            //do something later when date is reached
            if (distance < 0) {
                // document.getElementsByClassName("headline").innerText = "It's my birthday!";
                // document.getElementsByClassName("countdown").style.display = "none";
                // document.getElementsByClassName("content").style.display = "block";
                alert("Its is your Mission Day!");
                clearInterval(x);
            }
            //seconds
        }, 0)
}());