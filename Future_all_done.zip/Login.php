<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" integrity="" crossorigin="anonymous">

</head>

<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Additional CSS Files -->
<link rel="stylesheet" href="assets/css/fontawesome.css">
<link rel="stylesheet" href="assets/css/templatemo-grad-school.css">
<link rel="stylesheet" href="assets/css/owl.css">
<link rel="stylesheet" href="assets/css/lightbox.css">


<style>
        body { background:scroll;
        color: violet;
        font-family: Arial, Helvetica, sans-serif;
        background-color:darkgoldenrod;
        }
    </style>
</head>
<body>
 <!-- this is a transparent field form  -->
 <section class="section coming-soon" data-section="section3">
<h3 align="center" style="font: size 23px;color: gold;"> Welcome...</h3>
    <div class="container" id="container">
    <fieldset>  
    <h5>Login</h5>

<div class="container-fluid">
    <form action="serverlogins.php" method="post" name="Signup" id="signup" class="form-horizontal">
        <label for="Phonenumber" class="col-">Phone Number</label>
       <input type="text" class="form-control" id="Phone Number" name="Phone Number" placeholder="Enter your Phone Number" />
       
       <label for="email" class="col-">Email</label>
       <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email Address"/> 
       <label for="Password_1" class="col"> Password</label>
       <input type="password" class="form-control" id="Password_1" name="Password_1" placeholder="Enter a Strong Password" />
       
       <input type="Submit" class="btn btn-primary" name="submitSignUp" value="Submit" />
    <label for="signup" class="col">Don't have an account yet?</label>
    <a href="SignUp.php"><input type="Button" class="btn btn-primary" name="signup" value="Sign Up" />
      
    </form>
</div>
</fieldset>  
</div>
    </section>


    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/isotope.min.js"></script>
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/lightbox.js"></script>
<script src="assets/js/tabs.js"></script>
<script src="assets/js/video.js"></script>
<script src="assets/js/slick-slider.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
</html>